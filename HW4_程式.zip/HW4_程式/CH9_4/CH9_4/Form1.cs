﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CH9_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {              
                string name = textBox1.Text;
                string occupation = textBox2.Text;
                int age = int.Parse(textBox3.Text);
                string email = textBox4.Text;

                string homePhone = textBox6.Text;
                string business = textBox7.Text;
                string cellPhone = textBox8.Text;

                PhoneList phone = new PhoneList(homePhone, business, cellPhone);

                Cards card = new Cards(name, occupation, age, phone, email);

                textBox5.Text = card.GetCard();
            }
            catch
            {
                textBox5.Text = $"輸入欄位有錯誤 , 請重新輸入";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
        }
    }
}
