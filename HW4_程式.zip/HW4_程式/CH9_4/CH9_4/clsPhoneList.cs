﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH9_4
{
    public class PhoneList
    {
        public string HomePhone { get; set; }
        public string Business { get; set; }
        public string CellPhone { get; set; }

        public PhoneList(string homePhone, string business, string cellPhone)
        {
            HomePhone = homePhone;
            Business = business;
            CellPhone = cellPhone;
        }

        public override string ToString()
        {
            return $"\r\n    住家 : {HomePhone} \r\n    公司 : {Business} \r\n   手機 : {CellPhone}";
        }
    }
}
