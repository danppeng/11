﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH9_4
{
    public class Cards
    {
        public string Name { get; set; }
        public string Occupation { get; set; }
        public int Age { get; set; }
        public PhoneList Phone { get; set; }
        public string Email { get; set; }

        public Cards(string name, string occupation, int age, PhoneList phone, string email)
        {
            Name = name;
            Occupation = occupation;
            Age = age;
            Phone = phone;
            Email = email;
        }
        public string GetCard()
        {
            return $"姓名 : {Name}\r\n" +
                   $"職業 : {Occupation}\r\n" +
                   $"年齡 : {Age}\r\n" +
                   $"電話 : {Phone}\r\n" +
                   $"E-mail : {Email}\r\n";
        }
    }
}
